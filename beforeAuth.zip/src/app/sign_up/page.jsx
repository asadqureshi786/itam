
import Auth_SignUp from "@/components/Auth/SignUp"
export default function SignUp(){
    return (
        <>
            <Auth_SignUp/>
        </>
    )
}