
import TicketViewChat from "@/components/Ticket/TicketViewChat"

export default function Ticket_View(){
    return(
        <>
        
            <TicketViewChat/>
       
        </>
    )
}