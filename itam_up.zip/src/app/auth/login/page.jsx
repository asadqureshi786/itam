
import Auth_Login from "@/components/Auth/Login"
export default function Login(){
    return (
        <>
            <Auth_Login/>
        </>
    )
}